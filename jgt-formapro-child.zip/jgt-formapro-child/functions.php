<?php
/**
 * Forma Pro Child Theme
 *
 * Place any custom functionality/code snippets here.
 */

function jgtformapro_child_styles() {
	wp_enqueue_style( 'formapro-parent-theme-css', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'jgtformapro_child_styles' );
