<?php
/**
 * Azalea Pro Child Theme
 *
 * Place any custom functionality/code snippets here.
 */

function jgtazaleapro_child_styles() {
	wp_enqueue_style( 'azaleapro-parent-theme-css', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'jgtazaleapro_child_styles' );
